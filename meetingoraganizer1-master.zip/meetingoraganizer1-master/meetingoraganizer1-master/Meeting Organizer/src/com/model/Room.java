package com.model;

public class Room {
	private String roomId;
	private String roomName;
	private String floor;
	private String roomIncharge;
	private int capacity;
	private String status;



	public String getRoomId() {
		return roomId;
	}


	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}


	public String getRoomName() {
		return roomName;
	}


	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}


	public String getFloor() {
		return floor;
	}


	public void setFloor(String floor) {
		this.floor = floor;
	}


	public String getRoomIncharge() {
		return roomIncharge;
	}


	public void setRoomIncharge(String roomIncharge) {
		this.roomIncharge = roomIncharge;
	}





	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public int getCapacity() {
		return capacity;
	}


	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}


	public Room() {
		super();

	}
	public Room(String roomId, String roomName, String floor, String roomIncharge, int capacity, String status) {
		super();
		this.roomId = roomId;
		this.roomName = roomName;
		this.floor = floor;
		this.roomIncharge = roomIncharge;
		this.capacity = capacity;
		this.status = status;
	}


	@Override
	public String toString() {
		return "Room [roomId=" + roomId + ", roomName=" + roomName + ", floor=" + floor + ", roomIncharge="
				+ roomIncharge + ", capacity=" + capacity + ", status=" + status + "]";
	}

}
